-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Lun 06 Octobre 2014 à 23:02
-- Version du serveur :  5.6.17-log
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `edq`
--
CREATE DATABASE IF NOT EXISTS `edq` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `edq`;

-- --------------------------------------------------------

--
-- Structure de la table `contact`
--

DROP TABLE IF EXISTS `contact`;
CREATE TABLE IF NOT EXISTS `contact` (
  `IdContact` int(11) NOT NULL AUTO_INCREMENT,
  `IdContactRef` int(11) NOT NULL,
  `ContactType` varchar(8) NOT NULL,
  `Name` varchar(64) NOT NULL,
  `ShortName` varchar(16) DEFAULT NULL,
  `Title` varchar(16) DEFAULT NULL,
  `EMail` varchar(128) NOT NULL,
  `Phone1` varchar(23) DEFAULT NULL,
  `Phone2` varchar(23) DEFAULT NULL,
  `Address` text,
  `ZipCode` varchar(8) DEFAULT NULL,
  `City` varchar(64) DEFAULT NULL,
  `Enabled` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`IdContact`),
  KEY `Enabled` (`Enabled`),
  KEY `IdContactRef` (`IdContactRef`),
  KEY `EMail` (`EMail`),
  KEY `Name` (`Name`),
  KEY `ContactType` (`ContactType`),
  KEY `Title` (`Title`),
  KEY `ShortName` (`ShortName`),
  KEY `ZipCode` (`ZipCode`),
  KEY `City` (`City`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=766 ;

--
-- Contenu de la table `contact`
--

INSERT INTO `contact` (`IdContact`, `IdContactRef`, `ContactType`, `Name`, `ShortName`, `Title`, `EMail`, `Phone1`, `Phone2`, `Address`, `ZipCode`, `City`, `Enabled`) VALUES
(-1, 0, 'ENT', 'VTS', 'VTS', '', '', '', '', '', '', '', 1),
(1, 0, '', 'Administrateur', 'sys', '', '', '', '', '', '', '', 1),
(715, 0, '', 'Opérateur', 'OPER', '', '', '', '', '', '', '', 1),
(720, 0, '', 'Olivier DUFOSSE', 'OD', 'M', '', '', NULL, NULL, NULL, NULL, 1),
(722, 0, '', 'Georges BRICHON', 'GB', 'M', '', '', NULL, NULL, NULL, NULL, 1),
(742, 0, '', 'Christian FEVRE', 'CF', 'M.', '', '', NULL, NULL, NULL, NULL, 1),
(744, 0, '', 'Prissé', '', '', '', '', '', '', '', '', 1),
(745, 0, '', 'Sologny', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 1),
(747, 0, '', 'Verzé', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 1),
(757, 0, 'DOM', 'Externes', '', '', '', '', '', '', '', '', 1),
(758, 0, 'ENT', 'DIVERS', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 1),
(759, 0, 'DOM', 'Transporteurs', '', '', '', '', '', '', '', '', 1),
(761, 0, 'DOM', 'Assemblages', '', '', '', '', '', '', '', '', 1),
(762, 0, '', 'Vincent BIGEARD', 'VB', NULL, '', '', NULL, NULL, NULL, NULL, 1),
(763, 0, '', 'Sylvain JOLIVET', 'SJ', NULL, '', '', NULL, NULL, NULL, NULL, 1),
(764, 0, '', 'Rémi MOLLE', 'RM', NULL, '', '', NULL, NULL, NULL, NULL, 1),
(765, 0, '', 'Gilles CORTAMBERT', 'GC', NULL, '', '', NULL, NULL, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Structure de la table `contactparam`
--

DROP TABLE IF EXISTS `contactparam`;
CREATE TABLE IF NOT EXISTS `contactparam` (
  `IdContact` int(11) NOT NULL,
  `Domain` varchar(16) NOT NULL,
  `IdParam` varchar(16) NOT NULL,
  `Index` tinyint(4) NOT NULL DEFAULT '0',
  `Data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`IdContact`,`Domain`,`IdParam`,`Index`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `localparameter`
--

DROP TABLE IF EXISTS `localparameter`;
CREATE TABLE IF NOT EXISTS `localparameter` (
  `Domain` varchar(16) NOT NULL,
  `IdParam` varchar(16) NOT NULL,
  `Label` varchar(128) DEFAULT NULL,
  `Value` varchar(128) DEFAULT NULL,
  `ValueType` varchar(16) DEFAULT NULL,
  `Description` varchar(1024) DEFAULT NULL,
  `Data` text,
  `SortIndex` int(11) NOT NULL DEFAULT '1',
  `IsSystem` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Domain`,`IdParam`),
  KEY `SortIndex` (`SortIndex`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `localparameter`
--

INSERT INTO `localparameter` (`Domain`, `IdParam`, `Label`, `Value`, `ValueType`, `Description`, `Data`, `SortIndex`, `IsSystem`) VALUES
('{SYS}', 'DBVERSION', NULL, 'v01-000-003-001', NULL, NULL, NULL, 1, 0);

-- --------------------------------------------------------

--
-- Structure de la table `node_comment`
--

DROP TABLE IF EXISTS `node_comment`;
CREATE TABLE IF NOT EXISTS `node_comment` (
  `id` int(10) unsigned NOT NULL,
  `value` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `node_comment`
--

INSERT INTO `node_comment` (`id`, `value`) VALUES
(1069, 'Application TerraFact'),
(1168, 'https://datatables.net/examples/'),
(1232, 'Lien de téléchargement du fichier .csv d''une table fournie par le noeud actuel :\n		< ?php /* télécharger */\n		$viewer = tree::get_node_by_name(''/_Exemples/Convertisseurs/table/csv'')[''id'']; /* === 1233 */\n		$viewer_options = "&node=" . $node[''id''] //fournisseur de données\n				. "&file--name=" . urlencode($node[''nm''])\n				. "&node--get=html"; // extrait les données depuis le html\n		? ><a class="file-download" href="view.php?id=<?= $viewer ?><?= $viewer_options ?>&vw=file.call">télécharger</a>\n	'),
(1251, 'Utilisation de la fonction page::view_url.\nFournit une url d''appel d''une page.\n< form action="<?= page::view_url( $node ) ?>" >...\n\njQuery.load\njQuery.ui.dialog\n'),
(1319, 'La page zip peut s''appeler directement par :\n< ?php\n$arguments[''backup''] = ''sql pages sources'';\ncall_page( ''/_System/Sauvegarde/zip'', $arguments);\n? >'),
(1320, '\n\nMYSQLDUMP doit être défini dans /conf/edQ.conf.php'),
(1341, 'exemple de manipulation Xml'),
(1350, 'retourne le code html des données fournies par l''arguments rows'),
(1361, 'Retourne le code html des données fournies par l''arguments rows.\nUtilise le plugin jquery dataTable\nL''argument columns est transmis au plugin.\nLa page html/table/rows appelle cette page si l''argument $--plugin.'),
(1378, 'Recherche dans les sources .php, .css, .js'),
(1391, 'ED 140811 : Modification du plugin dataTable pour que la propriété render puisse être une fonction qui retourne du jQuery'),
(1436, 'Affiche une page dans un bloc'),
(1447, 'retourne le code html des données fournies par l''arguments rows'),
(1449, 'Retourne le code html des données fournies par l''arguments rows.\nUtilise le plugin jquery dataTable\nL''argument columns est transmis au plugin.\nLa page html/table/rows appelle cette page si l''argument $--plugin.');

-- --------------------------------------------------------

--
-- Structure de la table `node_param`
--

DROP TABLE IF EXISTS `node_param`;
CREATE TABLE IF NOT EXISTS `node_param` (
  `id` int(10) unsigned NOT NULL,
  `param` varchar(32) NOT NULL,
  `domain` varchar(32) NOT NULL,
  `value` text,
  `sortIndex` int(11) NOT NULL DEFAULT '999',
  PRIMARY KEY (`id`,`param`,`domain`),
  KEY `sortIndex` (`sortIndex`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `node_param`
--

INSERT INTO `node_param` (`id`, `param`, `domain`, `value`, `sortIndex`) VALUES
(1100, 'sort', 'viewers', '["file-call","file-content","","node","comment","children"]', 999),
(1101, 'sort', 'viewers', '["file-call","file-content","","node","comment"]', 999),
(1111, 'sort', 'viewers', '["file-content","","node","comment","file-call"]', 999),
(1123, 'Caption', 'query', '''Noeud : '' . $node->name', 999),
(1123, 'Columns', 'query', '"IdContact" => array(\n	 "text" => "#"\n	 , "pk" => true\n	 , "attributes" => array(''style'' => "background-color: #FAFAFA")\n)\n, "Name" => array(\n	 "text" => "Nom"\n	 , "css" => "background-color: yellow"\n)\n, "EMail" => "EMail"\n, "Phone1" => array(\n	 "text" => function(){ return "Téléphone(s)"; }\n	 , "value" => function($row, $column){\n	 	 return $row["Phone1"] . ($row["Phone2"] == '''' ? '''' : '' - '' . $row["Phone2"]);\n	 })\n, "Phone2" => array("visible" => false)\n, "Address" => array("text" => "Adresse")\n, "ZipCode" => array("text" => "Code postal")\n, "City" => array("text" => "Ville")', 999),
(1123, 'Foot', 'query', 'function($node, $rows, $viewer){\n	 return ''<center>'' . count($rows) . '' ligne'' . (count($rows) > 1 ? ''s'' : '''') . ''</center>'';\n}', 999),
(1123, 'SQLDelete', 'query', 'DELETE FROM contact\nWHERE a.id = :ID', 999),
(1123, 'SQLInsert', 'query', 'INSERT INTO contact (id, name)\nVALUES(:ID, :NAME)', 999),
(1123, 'SQLSelect', 'query', 'SELECT IdContact, Name, `EMail`, `Phone1`, `Phone2`, `Address`, `ZipCode`, `City`\nFROM contact c\nWHERE c.Name <> ''''\nORDER BY c.Name\nLIMIT 0, 20', 999),
(1123, 'SQLUpdate', 'query', 'UPDATE contact\n	SET a.name = :NAME\nWHERE a.id = :ID', 999),
(1134, 'Columns', 'query', '"idContact" => "#",\n"name" => "Nom"', 999),
(1134, 'SQLSelect', 'query', 'SELECT a.idContact, a.name\nFROM contact a\nORDER BY name\nLIMIT 0, 55\n', 999),
(1157, 'Caption', 'query', '''Noeud : '' . $node->name', 999),
(1157, 'Columns', 'query', '"IdContact" => array(\n	 "text" => "#"\n	 , "pk" => true\n)\n, "Name" => array("text" => "Nom")\n, "EMail" => "EMail"\n, "Phone1" => array(\n	 "text" => function(){ return "Téléphone(s)"; }\n	 , "value" => function($row, $column){\n	 	 return $row["Phone1"] . ($row["Phone2"] == '''' ? '''' : '' - '' . $row["Phone2"]);\n	 })\n, "Phone2" => array("visible" => false)\n, "Address" => array("text" => "Adresse")\n, "ZipCode" => array("text" => "Code postal")\n, "City" => array("text" => "Ville")', 999),
(1157, 'Foot', 'query', 'function($node, $rows, $viewer){\n	 return ''<center>'' . count($rows) . '' ligne'' . (count($rows) > 1 ? ''s'' : '''') . ''</center>'';\n}', 999),
(1157, 'SQLDelete', 'query', 'DELETE FROM contact\nWHERE a.id = :ID', 999),
(1157, 'SQLInsert', 'query', 'INSERT INTO contact (id, name)\nVALUES(:ID, :NAME)', 999),
(1157, 'SQLSelect', 'query', 'SELECT IdContact, Name, `EMail`, `Phone1`, `Phone2`, `Address`, `ZipCode`, `City`\nFROM contact c\nWHERE c.Name <> ''''\nORDER BY c.Name\nLIMIT 0, 30', 999),
(1157, 'SQLUpdate', 'query', 'UPDATE contact\n	SET a.name = :NAME\nWHERE a.id = :ID', 999),
(1159, 'sort', 'viewers', '["file-call","file-content","","node","comment","children"]', 999),
(1162, 'Caption', 'query', '''Noeud : '' . $node->name', 999),
(1162, 'Columns', 'query', '"domain" => array(\n	 "text" => "Domaine"\n	 , "css" => "background-color: #FAFAFA;"\n)\n, "param" => array(\n	 "text" => "Paramètre"\n	 , "css" => "background-color: #FAFAFA;"\n)\n, "text" => "Nom"\n, "valueType" => "Type"\n, "icon" => "Image"\n, "defaultValue" => "Valeur par défaut"\n, "comment" => "Commentaire"\n, "sortIndex" => "Tri"', 999),
(1162, 'Foot', 'query', 'function($node, $rows, $viewer){\n	 return ''<center>'' . count($rows) . '' ligne'' . (count($rows) > 1 ? ''s'' : '''') . ''</center>'';\n}', 999),
(1162, 'SQLDelete', 'query', 'DELETE FROM contact\nWHERE a.id = :ID', 999),
(1162, 'SQLInsert', 'query', 'INSERT INTO contact (id, name)\nVALUES(:ID, :NAME)', 999),
(1162, 'SQLSelect', 'query', 'SELECT p.`domain`, p.`param`, p.`text`, p.`valueType`, p.`icon`, p.`defaultValue`, p.`comment`, p.`sortIndex`\n, COUNT(n.id) AS nbUse\nFROM \n	node_params p\nLEFT JOIN\n	node_param n\n	ON p.domain = n.domain\n	AND p.param = n.param\nGROUP BY\n	p.`domain`, p.`param`, p.`text`, p.`valueType`, p.`icon`, p.`defaultValue`, p.`comment`, p.`sortIndex`\nORDER BY\n	 p.`domain`, p.`sortIndex`, p.`text`, p.`param`\nLIMIT 20', 999),
(1162, 'SQLUpdate', 'query', 'UPDATE node_params p\nSET p.text = :TEXT\nWHERE p.domain = :DOMAIN\nAND p.param = :PARAM', 999),
(1170, 'sort', 'viewers', '["file-call","file-content","","node","comment","children"]', 999),
(1173, 'sort', 'viewers', '["file-content","file-call","","node","comment","children"]', 999),
(1176, 'sort', 'viewers', '["file-content","file-call","","node","comment","children"]', 999),
(1179, 'sort', 'viewers', '["file-content","file-call","","node","comment","children"]', 999),
(1182, 'sort', 'viewers', '["file-content","","node","comment","children","file-call"]', 999),
(1195, 'sort', 'viewers', '["file-call","file-content","","node","comment"]', 999),
(1196, 'sort', 'viewers', '["file-content","","node","comment","file-call"]', 999),
(1198, 'sort', 'viewers', '["file-call","","node","comment","file-content"]', 999),
(1202, 'sort', 'viewers', '["file-call","file-content","","node","comment","children"]', 999),
(1203, 'sort', 'viewers', '["file-call","file-content","","node","comment"]', 999),
(1215, 'sort', 'viewers', '["file-call","","node","comment","file-content"]', 999),
(1218, 'sort', 'viewers', '["file-call","file-content","","node","comment"]', 999),
(1222, 'sort', 'viewers', '["file-content","file-call","","node","comment","children"]', 999),
(1229, 'sort', 'viewers', '["file-call","file-content","","node","comment","children"]', 999),
(1230, 'sort', 'viewers', '["file-call","","node","comment","file-content"]', 999),
(1231, 'sort', 'viewers', '["file-call","file-content","","node","comment","children"]', 999),
(1232, 'sort', 'viewers', '["file-call","file-content","","node","comment","children"]', 999),
(1233, 'sort', 'viewers', '["file-content","file-call","","node","comment","children"]', 999),
(1234, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1236, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1241, 'sort', 'viewers', '["file-call","","node","comment","children","file-content"]', 999),
(1248, 'sort', 'viewers', '["file-call","","node","comment","children","file-content"]', 999),
(1250, 'sort', 'viewers', '["file-content","","node","comment","file-call"]', 999),
(1251, 'sort', 'viewers', '["file-call","file-content","","node","comment"]', 999),
(1319, 'sort', 'viewers', '["file-call","","node","comment","children","file-content"]', 999),
(1320, 'sort', 'viewers', '["file-call","","node","comment","file-content"]', 999),
(1322, 'sort', 'viewers', '["file-call","file-content","","node","comment","children"]', 999),
(1325, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1326, 'sort', 'viewers', '["file-content","file-call","comment","","node","children"]', 999),
(1327, 'sort', 'viewers', '["file-call","file-content","","node","comment","children"]', 999),
(1331, 'sort', 'viewers', '["file-content","","node","comment","file-call"]', 999),
(1342, 'sort', 'viewers', '["file-content","file-call","","node","comment","children"]', 999),
(1344, 'sort', 'viewers', '[]', 999),
(1349, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1350, 'sort', 'viewers', '["file-content","file-call","","comment","node","children"]', 999),
(1354, 'sort', 'viewers', '["","node","comment","children","file-content","file-call"]', 999),
(1356, 'sort', 'viewers', '["file-call","file-content","","node","comment"]', 999),
(1360, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1361, 'sort', 'viewers', '["file-content","file-call","","node","comment","children"]', 999),
(1367, 'sort', 'viewers', '["file-call","file-content","","node","comment","children"]', 999),
(1370, 'sort', 'viewers', '["file-call","file-content","children","","node","comment"]', 999),
(1372, 'sort', 'viewers', '["file-call","file-content","","node","comment"]', 999),
(1373, 'sort', 'viewers', '["file-call","file-content","","node","comment"]', 999),
(1374, 'sort', 'viewers', '["file-call","file-content","","node","comment"]', 999),
(1377, 'sort', 'viewers', '["","node","comment","children","file-content","file-call"]', 999),
(1378, 'sort', 'viewers', '["file-call","file-content","","node","comment"]', 999),
(1383, 'sort', 'viewers', '["file-call","file-content","","node","comment"]', 999),
(1385, 'sort', 'viewers', '["file-call","file-content","","node","comment"]', 999),
(1386, 'sort', 'viewers', '["file-call","","node","comment","children","file-content"]', 999),
(1387, 'sort', 'viewers', '["file-call","","node","comment","children","file-content"]', 999),
(1388, 'sort', 'viewers', '["file-call","file-content","","node","comment"]', 999),
(1390, 'sort', 'viewers', '["file-call","file-content","","node","comment"]', 999),
(1392, 'sort', 'viewers', '["file-content","","node","comment","file-call"]', 999),
(1393, 'sort', 'viewers', '["file-call","file-content","","node","comment"]', 999),
(1407, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1408, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1409, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1411, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1412, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1413, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1414, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1415, 'sort', 'viewers', '["file-call","file-content","","node","comment","children"]', 999),
(1416, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1417, 'sort', 'viewers', '["file-call","file-content","","node","comment"]', 999),
(1418, 'sort', 'viewers', '["file-call","file-content","","node","comment","children"]', 999),
(1420, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1422, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1426, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1427, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1428, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1429, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1432, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1433, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1434, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1435, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1436, 'sort', 'viewers', '["file-call","file-content","","node","comment","children"]', 999),
(1437, 'sort', 'viewers', '["file-call","file-content","","node","comment"]', 999),
(1438, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1442, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1443, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1444, 'sort', 'viewers', '["file-call","file-content","","node","comment","children"]', 999),
(1445, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1446, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1447, 'sort', 'viewers', '["file-content","file-call","","comment","node","children"]', 999),
(1448, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1449, 'sort', 'viewers', '["file-call","file-content","","node","comment","children"]', 999),
(1450, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1455, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1456, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1457, 'sort', 'viewers', '["file-content","file-call","","node","comment","children"]', 999),
(1458, 'sort', 'viewers', '["file-call","file-content","","node","comment"]', 999),
(1476, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1478, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1479, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1480, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1481, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1483, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1486, 'sort', 'viewers', '["file-call","file-content","","node","comment"]', 999),
(1487, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1488, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1489, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1498, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1499, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1503, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1504, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1506, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1508, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1509, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1510, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1512, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1513, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1514, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1515, 'sort', 'viewers', '["file-content","file-call","","node","comment"]', 999),
(1544, 'sort', 'viewers', '["file-call","file-content","","node","comment"]', 999),
(1545, 'sort', 'viewers', '["file-call","file-content","","node","comment"]', 999),
(1546, 'sort', 'viewers', '["file-call","file-content","","node","comment"]', 999);

-- --------------------------------------------------------

--
-- Structure de la table `node_params`
--

DROP TABLE IF EXISTS `node_params`;
CREATE TABLE IF NOT EXISTS `node_params` (
  `param` varchar(32) NOT NULL,
  `domain` varchar(32) NOT NULL,
  `text` varchar(64) DEFAULT NULL,
  `valueType` varchar(128) DEFAULT NULL,
  `icon` varchar(64) DEFAULT NULL,
  `defaultValue` text,
  `comment` text,
  `sortIndex` int(11) NOT NULL DEFAULT '999',
  PRIMARY KEY (`param`,`domain`),
  KEY `sortIndex` (`sortIndex`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `node_params`
--

INSERT INTO `node_params` (`param`, `domain`, `text`, `valueType`, `icon`, `defaultValue`, `comment`, `sortIndex`) VALUES
('Caption', 'query', 'Titre', NULL, 'file file-html', 'function($node, $rows, $viewer){\n	 return ''Noeud : '' . $node["nm"];\n}', NULL, 1),
('Columns', 'query', 'Colonnes', NULL, NULL, '"IdContact" => array("text" => "#")\n, "Name" => array("text" => "Nom")\n, "EMail" => "EMail"\n, "Phone1" => array(\n	 "text" => function(){ return "Téléphone(s)"; }\n	 , "value" => function($row, $column){\n	 	 return $row["Phone1"] . ($row["Phone2"] == '''' ? '''' : '' - '' . $row["Phone2"]);\n	 })\n, "Phone2" => array("visible" => false)\n, "Address" => array("text" => "Adresse")\n, "ZipCode" => array("text" => "Code postal")\n, "City" => array("text" => "Ville")', NULL, 3),
('Foot', 'query', 'Pied de table', NULL, NULL, 'function($node, $rows, $viewer){\n	 return ''<center>'' . count($rows) . '' ligne'' . (count($rows) > 1 ? ''s'' : '''') . ''</center>'';\n}', NULL, 5),
('Footer', 'query', 'Pieds de colonnes', NULL, NULL, NULL, NULL, 4),
('SQLDelete', 'query', '', NULL, NULL, 'DELETE FROM contactWHERE a.id = :ID', NULL, 8),
('SQLInsert', 'query', '', NULL, NULL, 'INSERT INTO contact (id, name)VALUES(:ID, :NAME)', NULL, 7),
('SQLSelect', 'query', '', NULL, 'file file-sql', 'SELECT a.id, a.name\nFROM contact a\nORDER BY name\nLIMIT 0, 55', NULL, 2),
('SQLUpdate', 'query', NULL, NULL, NULL, 'UPDATE contact\n	SET a.name = :NAME\nWHERE a.id = :ID', NULL, 6);

-- --------------------------------------------------------

--
-- Structure de la table `parameter`
--

DROP TABLE IF EXISTS `parameter`;
CREATE TABLE IF NOT EXISTS `parameter` (
  `Domain` varchar(16) NOT NULL,
  `IdParam` varchar(16) NOT NULL,
  `Label` varchar(128) DEFAULT NULL,
  `Value` varchar(128) DEFAULT NULL,
  `ValueType` varchar(16) DEFAULT NULL,
  `Image` varchar(32) DEFAULT NULL,
  `Description` varchar(1024) DEFAULT NULL,
  `Data` text,
  `SortIndex` int(11) NOT NULL DEFAULT '1',
  `IsSystem` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Domain`,`IdParam`),
  KEY `SortIndex` (`SortIndex`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `parameter`
--

INSERT INTO `parameter` (`Domain`, `IdParam`, `Label`, `Value`, `ValueType`, `Image`, `Description`, `Data`, `SortIndex`, `IsSystem`) VALUES
('.', '.', 'Domaines', '', '', NULL, NULL, '', 0, 1),
('.', 'ART', 'Articles', '', '', 'Article', '', '', 9999, 0),
('.', 'CONT', 'Contacts', '', ' ', 'Contact', '', '', 9999, 0),
('.', 'DOSS', 'Dossiers', NULL, NULL, 'Dossiers', NULL, NULL, 9999, 0),
('.', 'IMAGE', 'Images', '', '', 'Image', '', '', 9999, 0),
('.', 'Q', 'Requêtes', NULL, NULL, NULL, NULL, NULL, 1, 0),
('.', 'UNIT', 'Unités de mesure', '', '', 'Selection', '', '', 9999, 0),
('.', 'USER', 'Utilisateurs', NULL, NULL, 'User', NULL, NULL, 9999, 1),
('.', 'VALUETYPE', 'Types de valeurs', 'Selection', ' ', 'Selection', '', NULL, 9999, 0),
('ART', 'ART.CAT', 'Catégories', '', '', NULL, '', '', 9999, 0),
('ART.CAT', 'ART.CAT.HTML', 'Html', 'ANA', '', NULL, '', '', 9999, 0),
('ART.CAT.HTML', 'default', '(par défault)', '<span class="edvicon <?=edv.qv.Params.image(this.Value("Image"))?>"><?=this.Value("Name")?></span>', NULL, NULL, NULL, '', 0, 0),
('CONT', 'CONT.P', 'Paramètres des contacts', NULL, NULL, NULL, NULL, NULL, 9999, 0),
('CONT', 'CONT.TITLE', 'Civilités', NULL, NULL, NULL, NULL, NULL, 9999, 0),
('CONT', 'CONT.TYPE', 'Types de contact', NULL, NULL, NULL, NULL, NULL, 9999, 0),
('CONT.P', 'CONT.P.ETAB', 'Etablissement', NULL, NULL, NULL, NULL, NULL, 9999, 0),
('CONT.P.ETAB', 'Code', 'Code interne', NULL, 'Selection', NULL, NULL, '{"values":[1,2,3,4,5,99]}', 9999, 0),
('CONT.TITLE', '', '', NULL, NULL, NULL, NULL, NULL, 0, 0),
('CONT.TITLE', 'M', 'M.', NULL, NULL, NULL, NULL, NULL, 1, 0),
('CONT.TITLE', 'MME', 'Mme', NULL, NULL, NULL, NULL, NULL, 2, 0),
('CONT.TYPE', '', 'Contact', '', '', 'Contact', '', '', 0, 0),
('CONT.TYPE', 'BOSS', 'Responsable', '', '', NULL, NULL, '', 4, 0),
('CONT.TYPE', 'DOM', 'Domaine', NULL, NULL, NULL, NULL, NULL, 9999, 0),
('CONT.TYPE', 'ENT', 'Entreprise', NULL, NULL, NULL, NULL, NULL, 9999, 0),
('CONT.TYPE', 'ETAB', 'Etablissement', NULL, NULL, NULL, NULL, '', 9999, 0),
('DOSS', 'DOSS.P', 'Paramètres', NULL, NULL, NULL, NULL, NULL, 9999, 0),
('DOSS', 'DOSS.STA', 'Statuts des dossiers', NULL, NULL, NULL, NULL, '', 6, 0),
('DOSS', 'DOSS.TYPE', 'Types', '', '', NULL, NULL, '', 5, 0),
('DOSS.P', 'COM', 'Commentaire interne', NULL, 'Text', NULL, NULL, NULL, 99999, 0),
('DOSS.STA', 'ANNUL', 'Annulé', NULL, NULL, NULL, NULL, NULL, 4, 0),
('DOSS.STA', 'CLOS', 'Terminé', NULL, NULL, NULL, NULL, NULL, 10, 0),
('DOSS.STA', 'NEW', 'Nouveau', NULL, NULL, NULL, NULL, NULL, 0, 0),
('DOSS.STA', 'OK', 'Enregistré', NULL, NULL, NULL, NULL, NULL, 1, 0),
('DOSS.TYPE', 'FACT', 'Facture', '', '', 'Dossier', '', '', 0, 0),
('IMAGE', 'Array', 'Tableau', 'imgEDVTypeArray', '', 'Array', '', '', 3, 0),
('IMAGE', 'Article', 'Article', 'edvimgArticle', NULL, 'Article', NULL, NULL, 300, 0),
('IMAGE', 'Articles', 'Articles', 'edvimgArticles', NULL, 'Articles', NULL, NULL, 301, 0),
('IMAGE', 'ArtIN', 'Vers conteneur', 'edvimgArtIN', NULL, 'ArtIN', NULL, NULL, 1000, 0),
('IMAGE', 'ArtOUT', 'Depuis conteneur', 'edvimgArtOUT', NULL, 'ArtOUT', NULL, NULL, 1100, 0),
('IMAGE', 'Boolean', 'Oui/Non', NULL, NULL, 'Boolean', NULL, NULL, 9900, 0),
('IMAGE', 'Button', 'Action', NULL, NULL, 'Button', NULL, NULL, 9999, 0),
('IMAGE', 'CatTRANS', 'Transferts', 'edvimgCatTRANS', NULL, 'CatTRANS', NULL, NULL, 2000, 0),
('IMAGE', 'Contact', 'Contact', 'edvimgContact', NULL, 'Contact', NULL, NULL, 9999, 0),
('IMAGE', 'Cuve', 'Cuve', 'edvimgCuve', NULL, 'Cuve', NULL, NULL, 100, 0),
('IMAGE', 'CuveCAM', 'Camion', 'edvimgCuveCAM', NULL, 'CuveCAM', NULL, NULL, 120, 0),
('IMAGE', 'CuveCIMENT', 'Cuve Ciment', 'edvimgCuveCIMENT', NULL, 'CuveCIMENT', NULL, NULL, 102, 0),
('IMAGE', 'CuveEMA', 'Cuve Email', 'edvimgCuveEMAIL', NULL, 'CuveEMA', NULL, NULL, 102, 0),
('IMAGE', 'CuveEPOX', 'Cuve Epoxy', 'edvimgCuveEPOX', NULL, 'CuveEPOX', NULL, NULL, 102, 0),
('IMAGE', 'CuveFIBR', 'Cuve Fibre', 'edvimgCuveFIBR', NULL, 'CuveFIBR', NULL, NULL, 102, 0),
('IMAGE', 'CuveFUT', 'Fût', 'edvimgCuveFUT', NULL, 'Cuve', NULL, NULL, 109, 0),
('IMAGE', 'CuveINOX', 'Cuve Inox', 'edvimgCuveINOX', NULL, 'CuveINOX', NULL, NULL, 102, 0),
('IMAGE', 'CuvePRESS', 'Pressoir', 'edvimgCuvePRESS', NULL, 'CuvePRESS', NULL, NULL, 110, 0),
('IMAGE', 'CuveRESIN', 'Cuve Résine', 'edvimgCuveRESIN', NULL, 'CuveRESIN', NULL, NULL, 103, 0),
('IMAGE', 'Cuves', 'Cuves', 'edvimgCuves', NULL, 'Cuves', NULL, NULL, 101, 0),
('IMAGE', 'DateTime', 'Date', NULL, NULL, 'DateTime', NULL, NULL, 9999, 0),
('IMAGE', 'Domain', 'Domaine', 'imgEDVTypeDomain', '', 'Domain', '', '', 1, 0),
('IMAGE', 'DomSys', 'Dossier système', 'imgEDVTypeDomSys', '', 'DomSys', '', '', 2, 0),
('IMAGE', 'Dossier', 'Dossier', 'edvimgDossier', NULL, 'Dossier', NULL, NULL, 9999, 0),
('IMAGE', 'Dossiers', 'Dossiers', 'edvimgDossiers', NULL, 'Dossiers', NULL, NULL, 9999, 0),
('IMAGE', 'EDV', 'EDV', NULL, NULL, 'EDV', NULL, NULL, 9999, 0),
('IMAGE', 'Fourn', 'Fournisseur', 'edvimgFourn', NULL, 'Fourn', NULL, NULL, 3000, 0),
('IMAGE', 'Image', 'Image', NULL, NULL, 'Image', NULL, NULL, 9999, 0),
('IMAGE', 'IN', 'Entrant', 'edvimgArrowIN', NULL, 'IN', NULL, NULL, 1001, 0),
('IMAGE', 'Info', 'Info', 'edvimgInfo', NULL, 'Info', NULL, NULL, 9999, 0),
('IMAGE', 'LgExec', 'Tâche à faire', 'edvimgLgExec', NULL, 'LgExec', NULL, NULL, 9999, 0),
('IMAGE', 'Location', 'Localisation', 'edvimgLocation', NULL, 'Location', NULL, NULL, 9999, 0),
('IMAGE', 'Num', 'Nombre', NULL, NULL, 'Num', NULL, NULL, 9999, 0),
('IMAGE', 'Object', 'Objet', NULL, NULL, 'Object', NULL, NULL, 9999, 0),
('IMAGE', 'Ok', 'Ok', 'imgEDVTypeTrue', NULL, 'Ok', NULL, NULL, 9901, 0),
('IMAGE', 'Oper', 'Opération', 'imgEDVTypeNull', NULL, 'Oper', NULL, NULL, 9999, 0),
('IMAGE', 'OUT', 'Sortant', 'edvimgArrowOUT', NULL, 'OUT', NULL, NULL, 1101, 0),
('IMAGE', 'Print', 'Impression', NULL, NULL, 'Print', NULL, NULL, 9999, 0),
('IMAGE', 'ProdVin', 'Produit vinicole', 'edvimgProdVin', NULL, 'ProdVin', NULL, NULL, 200, 0),
('IMAGE', 'ProdVin.B', 'Vin blanc', 'edvimgProdVinB', '', 'ProdVin.B', '', '', 210, 0),
('IMAGE', 'ProdVin.C', 'Vin crémant', 'edvimgProdVinC', NULL, 'ProdVin.C', NULL, NULL, 211, 0),
('IMAGE', 'ProdVin.O', 'Vin rosé', 'edvimgProdVinO', NULL, 'ProdVin.O', NULL, NULL, 212, 0),
('IMAGE', 'ProdVin.R', 'Vin rouge', 'edvimgProdVinR', NULL, 'ProdVin.R', NULL, NULL, 213, 0),
('IMAGE', 'Selection', 'Sélection', NULL, NULL, 'Selection', NULL, NULL, 9999, 0),
('IMAGE', 'Site', 'Site', 'edvimgSite', NULL, 'Site', NULL, NULL, 9999, 0),
('IMAGE', 'Text', 'Texte', 'imgEDVTypeText', NULL, 'Text', NULL, NULL, 5, 0),
('IMAGE', 'Tree', 'Arbre', 'edvimgTree', NULL, 'Tree', NULL, NULL, 9999, 0),
('IMAGE', 'User', 'Utilisateur', 'edvimgUser', NULL, 'User', NULL, NULL, 9999, 0),
('Q', 'Q.P', 'Paramètres de requête', NULL, NULL, NULL, NULL, NULL, 1, 0),
('Q.P', 'SQL', 'SQL', NULL, NULL, NULL, NULL, NULL, 1, 0),
('Q.P.SQL', 'DELETE', 'DELETE', NULL, NULL, NULL, NULL, NULL, 1, 0),
('Q.P.SQL', 'INSERT', 'INSERT', NULL, NULL, NULL, NULL, NULL, 1, 0),
('Q.P.SQL', 'SELECT', 'SELECT', NULL, NULL, NULL, NULL, 'SELECT *\r\nFROM table', 1, 0),
('Q.P.SQL', 'UPDATE', 'UPDATE', NULL, NULL, NULL, NULL, NULL, 1, 0),
('UNIT', '', ' ', NULL, 'Text', 'Text', NULL, NULL, -1, 0),
('UNIT', '%', '%', NULL, 'Double', 'Num', NULL, NULL, 7, 0),
('UNIT', 'bt', 'boite(s)', NULL, 'Double', 'Num', NULL, NULL, 4, 0),
('UNIT', 'g', 'g', NULL, 'Double', 'Num', NULL, NULL, 2, 0),
('UNIT', 'H', 'Heure', NULL, 'Double', 'DateTime', NULL, NULL, 5, 0),
('UNIT', 'J', 'Jour', NULL, 'Double', 'DateTime', NULL, NULL, 6, 0),
('UNIT', 'Kg', 'Kg', NULL, 'Double', 'Num', NULL, NULL, 1, 0),
('UNIT', 'L', 'L', NULL, 'Double', 'Num', NULL, NULL, 0, 0),
('UNIT', 'mg', 'mg', NULL, 'Double', 'Num', NULL, NULL, 2, 0),
('UNIT', 'u', 'unité', NULL, 'Double', 'Num', NULL, NULL, 4, 0),
('USER', 'USER.TYPE', 'Type d''utilisateur', NULL, NULL, NULL, NULL, NULL, 9999, 0),
('USER.TYPE', '1', 'Système', NULL, NULL, NULL, NULL, NULL, 9999, 0),
('USER.TYPE', '1024', 'Invité', NULL, NULL, NULL, NULL, NULL, 0, 0),
('USER.TYPE', '16', 'Responsable', NULL, NULL, NULL, NULL, NULL, 4, 0),
('USER.TYPE', '256', 'Interne', NULL, NULL, NULL, NULL, NULL, 0, 0),
('USER.TYPE', '4', 'Administrateur', NULL, NULL, NULL, NULL, NULL, 8, 0),
('USER.TYPE', '64', 'Utilisateur', NULL, NULL, NULL, NULL, NULL, 0, 0),
('VALUETYPE', ' ', '-', '', '', 'Null', '', NULL, -1, 0),
('VALUETYPE', 'Boolean', 'Oui/Non', '', 'Boolean', 'Boolean', '', NULL, 2, 0),
('VALUETYPE', 'DateTime', 'Date/Heure', '', 'DateTime', 'DateTime', '', NULL, 6, 0),
('VALUETYPE', 'Double', 'Numérique', '0', 'Double', 'Num', '', NULL, 0, 0),
('VALUETYPE', 'Image', 'Image', '', 'Image', 'Image', '', NULL, 999, 0),
('VALUETYPE', 'Selection', 'Sélection', '', 'Selection', 'Selection', '', NULL, 5, 0),
('VALUETYPE', 'Text', 'Texte', '', 'Text', 'Text', '', NULL, 1, 0);

-- --------------------------------------------------------

--
-- Structure de la table `rights`
--

DROP TABLE IF EXISTS `rights`;
CREATE TABLE IF NOT EXISTS `rights` (
  `UserType` int(11) NOT NULL,
  `Domain` varchar(256) NOT NULL,
  `Rights` int(8) NOT NULL,
  `Data` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`UserType`,`Domain`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `rights`
--

INSERT INTO `rights` (`UserType`, `Domain`, `Rights`, `Data`) VALUES
(1, 'Admin', 15, NULL),
(1, 'Article', 15, NULL),
(1, 'Client', 15, NULL),
(1, 'design', 15, NULL),
(1, 'Devis', 15, NULL),
(1, 'Dossier', 15, NULL),
(1, 'Remise', 15, NULL),
(4, 'Admin', 15, NULL),
(4, 'Article', 15, NULL),
(4, 'Client', 15, NULL),
(4, 'Devis', 15, NULL),
(4, 'Dossier', 15, NULL),
(4, 'Remise', 15, NULL),
(16, 'Admin', 0, NULL),
(16, 'Client', 15, NULL),
(16, 'Devis', 15, NULL),
(16, 'Dossier', 15, NULL),
(16, 'Remise', 15, NULL),
(64, 'Admin', 0, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `rightsdomain`
--

DROP TABLE IF EXISTS `rightsdomain`;
CREATE TABLE IF NOT EXISTS `rightsdomain` (
  `Domain` varchar(256) NOT NULL,
  `Name` varchar(256) NOT NULL,
  PRIMARY KEY (`Domain`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `rightsdomain`
--

INSERT INTO `rightsdomain` (`Domain`, `Name`) VALUES
('Admin', 'Administration'),
('Article', 'Gestion des articles'),
('Client', 'Gestion des clients'),
('Dossier', 'Gestion des dossiers');

-- --------------------------------------------------------

--
-- Structure de la table `tree_data`
--

DROP TABLE IF EXISTS `tree_data`;
CREATE TABLE IF NOT EXISTS `tree_data` (
  `id` int(10) unsigned NOT NULL,
  `nm` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'nom',
  `typ` varchar(32) DEFAULT NULL COMMENT 'source externe',
  `ext` varchar(64) DEFAULT NULL COMMENT 'Clé dans la source externe',
  `params` text,
  `design` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Visible uniquement en mode Design',
  `icon` varchar(32) DEFAULT NULL COMMENT 'class de l''icône',
  `color` varchar(16) DEFAULT NULL,
  `ulvl` int(11) NOT NULL DEFAULT '0' COMMENT 'User level',
  `user` int(11) NOT NULL DEFAULT '0' COMMENT 'private for user',
  PRIMARY KEY (`id`),
  KEY `typ` (`typ`),
  KEY `ext` (`ext`),
  KEY `ulvl` (`ulvl`),
  KEY `user` (`user`),
  KEY `design` (`design`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `tree_data`
--

INSERT INTO `tree_data` (`id`, `nm`, `typ`, `ext`, `params`, `design`, `icon`, `color`, `ulvl`, `user`) VALUES
(0, 'decompte par critere', NULL, NULL, NULL, 1, NULL, NULL, 256, 0),
(1, 'edQ', 'folder', '', '', 1, 'file file-folder-sys', NULL, 256, 0),
(1065, 'UPDATE', 'sql', '', 'UPDATE maTable\nSET name = :NAME\nWHERE id = :ID\nLIMIT 0, 1', 1, NULL, NULL, 256, 0),
(1069, 'TerraFact', 'folder', '', '', 0, 'file file-folder', '', 256, 0),
(1070, 'DB', 'folder', '', '', 1, NULL, NULL, 256, 0),
(1074, '_templates', 'folder', '', '', 1, 'file file-folder-sys', 'null', 256, 0),
(1078, 'css', 'css', '', '', 1, NULL, NULL, 256, 0),
(1094, 'SELECT', 'sql', '', 'SELECT *\nFROM maTable\nWHERE id = :ID\nORDER BY name\nLIMIT 0, 10', 1, 'file file-sql', NULL, 256, 0),
(1095, 'SQL', 'folder', '', '', 1, NULL, NULL, 256, 0),
(1097, 'INSERT', 'sql', '', 'INSERT INTO maTable (id, name)\nVALUES( :ID, :NAME )\nLIMIT 0, 1', 1, NULL, NULL, 256, 0),
(1098, 'DELETE', 'sql', '', 'DELETE FROM maTable\nWHERE id = :ID\nLIMIT 0, 1', 1, NULL, NULL, 256, 0),
(1100, 'Contacts', 'folder', '', '', 0, 'file file-folder', '', 256, 0),
(1101, 'Liste', 'php', '', '', 0, 'file file-query', NULL, 256, 0),
(1102, 'Edition', 'php', '', '', 1, 'file file-query', NULL, 256, 0),
(1103, 'dataSource', 'dataSource', '', '', 1, 'file file-iso', NULL, 256, 0),
(1104, 'html', 'html', '', '', 1, 'file file-file', NULL, 256, 0),
(1105, 'css', 'css', '', '', 1, NULL, NULL, 256, 0),
(1106, 'html', 'html', '', '', 1, 'file file-file', NULL, 256, 0),
(1107, 'php', 'php', '', '', 1, 'file file-php', NULL, 256, 0),
(1111, 'dataSource', 'dataSource', '', '', 1, 'file file-iso', NULL, 256, 0),
(1121, 'Xml', 'html', '', '', 0, 'file file-iso', '', 256, 0),
(1123, 'Requête', 'query', '', '', 1, 'file file-query', NULL, 256, 1),
(1133, 'rezo', 'folder', '', '', 0, 'file file-folder', '', 256, 0),
(1134, 'Requête', 'query', '', '', 1, 'file file-query', NULL, 256, 1),
(1157, 'Test', 'query', '', '', 1, 'file file-query', NULL, 256, 1),
(1158, '_System', 'folder', '', '', 1, 'file file-folder-sys', '#ebdab9', 256, 1),
(1159, 'Parametres', 'folder', '', '', 1, 'file file-folder', '#ffffff', 256, 0),
(1160, 'Liste', 'php', '', '', 1, 'file file-query', '#f0b2f0', 256, 1),
(1161, 'Edition', 'php', '', '', 1, 'file file-query', '#c1deab', 256, 1),
(1162, 'Requête', 'query', '', '', 1, 'file file-query', '#eaed91', 256, 1),
(1166, 'dataSource', 'dataSource', '', '', 1, 'file file-iso', '', 256, 0),
(1167, '_Exemples', 'folder', '', '', 1, 'file file-folder-sys', NULL, 256, 0),
(1168, 'dataTable', 'folder', '', '', 1, 'file file-folder', '', 256, 0),
(1169, 'Simple', 'folder', '', '', 1, 'file file-folder', NULL, 256, 0),
(1170, 'Zero config', 'php', '', '', 1, 'file file-php', NULL, 256, 0),
(1171, 'data', 'folder', '', '', 1, 'file file-file', NULL, 256, 0),
(1172, 'Ajax', 'folder', '', '', 1, 'file file-folder', NULL, 256, 0),
(1173, 'Array', 'php', '', '', 1, 'file file-php', NULL, 256, 0),
(1174, 'data', 'folder', '', '', 1, 'file file-file', NULL, 256, 0),
(1175, 'html', NULL, NULL, NULL, 1, NULL, NULL, 256, 0),
(1176, 'Objets JSON', 'php', '', '', 1, 'file file-php', NULL, 256, 0),
(1177, 'data', 'folder', '', '', 1, 'file file-file', NULL, 256, 0),
(1178, 'html', NULL, NULL, NULL, 1, NULL, NULL, 256, 0),
(1179, 'Objets complexes', 'php', '', '', 1, 'file file-php', NULL, 256, 0),
(1180, 'data', 'folder', '', '', 1, 'file file-file', NULL, 256, 0),
(1181, 'html', NULL, NULL, NULL, 1, NULL, NULL, 256, 0),
(1182, 'Details', 'php', '', '', 1, 'file file-php', NULL, 256, 0),
(1183, 'data', 'folder', '', '', 1, 'file file-file', NULL, 256, 0),
(1184, 'html', NULL, NULL, NULL, 1, NULL, NULL, 256, 0),
(1185, 'css', 'css', '', '', 1, 'file file-css', NULL, 256, 0),
(1186, 'images', 'folder', '', '', 1, 'file file-folder', NULL, 256, 0),
(1187, 'jquery', 'folder', '', '', 1, 'file file-folder', NULL, 256, 0),
(1188, 'jqGrid', 'folder', '', '', 1, 'file file-folder', NULL, 256, 0),
(1189, 'Hide Grouping Column', 'php', '', '', 1, 'file file-php', NULL, 256, 0),
(1190, 'data', 'folder', '', '', 1, 'file file-file', NULL, 256, 0),
(1191, 'html', NULL, NULL, NULL, 1, NULL, NULL, 256, 0),
(1192, 'css', 'css', '', '', 1, 'file file-css', NULL, 256, 0),
(1195, 'execute', 'php', '', '', 1, 'file file-php', '', 256, 0),
(1196, 'get_callstack', 'default', '', '', 1, 'file file-file', '', 256, 0),
(1198, 'arguments', 'php', '', '', 1, 'file file-php', '', 256, 0),
(1199, 'javascript', 'default', '', '', 1, 'file file-folder-sys', '', 256, 0),
(1200, 'view dialog', 'default', '', '', 1, 'file file-file', '', 256, 0),
(1202, 'call', 'php', '', '', 1, 'file file-php', '', 256, 0),
(1203, 'subpage', 'html', '', '', 1, 'file file-htm', '', 256, 0),
(1204, 'Xml', 'html', '', '', 0, 'file file-file', '', 256, 0),
(1205, 'Load, Save', 'default', '', '', 1, 'file file-file', '', 256, 0),
(1208, 'Async+Sort', 'php', '', '', 1, 'file file-php', '', 256, 0),
(1209, 'data', 'folder', '', '', 1, 'file file-file', NULL, 256, 0),
(1210, 'html', NULL, NULL, NULL, 1, NULL, NULL, 256, 0),
(1211, 'css', 'css', '', '', 1, 'file file-css', NULL, 256, 0),
(1215, 'Fichiers .php residuels', 'default', '', '', 1, 'file file-file', '', 256, 0),
(1216, 'Pages', 'folder', '', '', 1, 'file file-folder', 'false', 256, 0),
(1218, 'Noeuds', 'default', '', '', 1, 'file file-file', '', 256, 0),
(1220, 'Editeurs', 'folder', '', '', 1, 'file file-folder', '', 256, 0),
(1221, 'CodeMirror', NULL, NULL, NULL, 1, NULL, NULL, 256, 0),
(1222, 'test', 'default', '', '', 1, 'file file-php', '', 256, 0),
(1229, 'Utilisateurs', 'folder', '', '', 1, 'file file-folder', '', 256, 0),
(1230, 'Liste', 'php', '', '', 1, 'file file-query', '', 256, 0),
(1231, 'Edition', 'php', '', '', 1, 'file file-query', NULL, 256, 1),
(1232, '_format', 'folder', '', '', 1, 'file file-folder-sys', '', 256, 0),
(1233, 'table', 'html', '', '', 1, 'file file-htm', '', 256, 0),
(1234, 'csv', 'folder', '', '', 1, 'file file-folder', '', 256, 0),
(1235, 'sub', NULL, NULL, NULL, 1, NULL, NULL, 256, 0),
(1236, 'rows', 'php', '', '', 1, 'file file-query', '', 256, 0),
(1239, 'Gestion - Compta', 'folder', '', '', 0, 'file file-folder', '#d5debf', 256, 0),
(1240, 'Temps de travail', 'folder', '', '', 0, 'file file-folder', '', 256, 0),
(1241, 'Analytique', 'php', '', '', 0, 'file file-query', '', 256, 0),
(1247, 'Details', 'php', '', '', 0, 'file file-query', '', 256, 0),
(1248, 'Analytique par contexte', 'php', '', '', 0, 'file file-query', '', 256, 0),
(1249, 'dataSource', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1250, 'TODO', 'html', '', '', 1, 'file file-file', '', 256, 0),
(1251, 'url', 'php', '', '', 1, 'file file-php', '', 256, 0),
(1319, 'Sauvegarde', 'folder', NULL, NULL, 0, 'file file-folder', NULL, 256, 0),
(1320, 'zip', 'php', '', '', 0, 'file file-iso', '', 256, 0),
(1321, 'Divers', 'folder', '', '', 1, 'file file-folder', '', 256, 0),
(1322, 'debug', 'folder', '', '', 1, 'file file-folder', '', 256, 0),
(1323, 'dialog', 'php', NULL, NULL, 0, 'file file-php', NULL, 256, 0),
(1324, 'server', 'php', NULL, NULL, 0, 'file file-php', NULL, 256, 0),
(1325, 'get', 'php', NULL, NULL, 0, 'file file-php', NULL, 256, 0),
(1326, 'Utilisateur', 'folder', '', '', 1, 'file file-folder', '', 256, 0),
(1327, 'Preferences', 'folder', NULL, NULL, 0, 'file file-folder', NULL, 256, 0),
(1328, 'session', 'php', '', '', 0, 'file file-php', '', 256, 0),
(1329, 'dialog', 'php', NULL, NULL, 0, 'file file-php', NULL, 256, 0),
(1331, 'set', 'php', '', '', 0, 'file file-php', '', 256, 0),
(1341, 'Filters', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1342, 'UI', 'folder', NULL, NULL, 0, 'file file-folder', NULL, 256, 0),
(1344, 'Layout', 'js', '', '', 0, 'file file-js', '', 256, 0),
(1345, '_html', 'folder', '', '', 1, 'file file-folder-sys', '', 256, 0),
(1346, 'input', 'folder', NULL, NULL, 0, 'file file-folder', NULL, 256, 0),
(1347, 'file', 'html', NULL, NULL, 0, 'file file-html', NULL, 256, 0),
(1348, 'table', 'folder', NULL, NULL, 0, 'file file-folder', NULL, 256, 0),
(1349, 'csv', 'php', NULL, NULL, 0, 'file file-php', NULL, 256, 0),
(1350, 'rows', 'php', NULL, NULL, 0, 'file file-php', NULL, 256, 0),
(1351, 'demo', 'default', NULL, NULL, 0, 'file file-file', NULL, 256, 0),
(1354, 'Ecritures', 'php', NULL, NULL, 0, 'file file-php', NULL, 256, 0),
(1355, 'csv', 'default', '', '', 1, 'file file-file', '', 256, 0),
(1356, 'Recherche', 'default', '', '', 1, 'file file-iso', '', 256, 0),
(1357, 'phpinfo', 'php', '', '', 0, 'file file-php', '', 256, 0),
(1360, 'form', 'php', '', '', 0, 'file file-htm', '', 256, 0),
(1361, 'dataTable', 'php', '', '', 0, 'file file-php', '', 256, 0),
(1362, 'demo', 'default', NULL, NULL, 0, 'file file-file', NULL, 256, 0),
(1363, 'sdn.org', 'folder', NULL, NULL, 0, 'file file-folder', NULL, 256, 0),
(1364, 'Synthese', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1365, 'PostFix', 'folder', NULL, NULL, 1, NULL, NULL, 256, 0),
(1366, 'conf', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1367, 'logs', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1368, 'section', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1369, 'sections', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1370, 'page', 'php', '', '', 1, 'file file-c', '', 256, 0),
(1371, 'image', 'folder', NULL, NULL, 0, 'file file-folder', NULL, 256, 0),
(1372, 'jquery-ui', 'php', NULL, NULL, 0, 'file file-php', NULL, 256, 0),
(1373, 'edQ', 'php', NULL, NULL, 0, 'file file-php', NULL, 256, 0),
(1374, 'helpers', 'php', '', '', 1, 'file file-c', '', 256, 0),
(1377, 'Sources', 'folder', '', '', 1, 'file file-folder', '', 256, 0),
(1378, 'Recherche', 'default', '', '', 1, 'file file-iso', '', 256, 0),
(1383, 'Favoris', 'html', NULL, NULL, 1, 'file file-html', NULL, 256, 0),
(1384, 'delete', 'php', '', '', 0, 'file file-php', '', 256, 0),
(1385, 'tree', 'php', '', '', 1, 'file file-c', '', 256, 0),
(1386, '_docs', 'folder', '', '', 1, 'file file-folder-sys', '#ffffff', 256, 0),
(1387, 'php', 'folder', NULL, NULL, 1, 'file file-folder', NULL, 256, 0),
(1388, 'Version', 'php', NULL, NULL, 1, 'file file-php', NULL, 256, 0),
(1390, 'Recherche', 'default', '', '', 1, 'file file-iso', '', 256, 0),
(1391, 'render as function', 'folder', '', '', 1, 'file file-folder', '', 256, 0),
(1392, 'submit', 'php', NULL, NULL, 1, 'file file-php', NULL, 256, 0),
(1393, 'cast to boolean', 'default', NULL, NULL, 1, 'file file-file', NULL, 256, 0),
(1398, 'vTiger', 'folder', NULL, NULL, 1, 'file file-folder', NULL, 256, 0),
(1399, 'CRM', 'folder', NULL, NULL, 1, 'file file-folder', NULL, 256, 0),
(1404, 'La Matrice', 'folder', '', '', 1, 'file file-folder', '', 256, 0),
(1405, 'Dev', 'folder', NULL, NULL, 1, 'file file-folder', NULL, 256, 0),
(1406, 'Imports4D', 'folder', NULL, NULL, 1, 'file file-folder', NULL, 256, 0),
(1407, 'csv', 'php', NULL, NULL, 1, 'file file-php', NULL, 256, 0),
(1408, 'critere_adr', 'php', NULL, NULL, 1, 'file file-php', NULL, 256, 0),
(1409, 'helpers', 'php', NULL, NULL, 1, 'file file-php', NULL, 256, 0),
(1410, 'dataSource', 'dataSource', NULL, NULL, 1, 'file file-iso', NULL, 256, 0),
(1411, 'adresse', 'php', '', '', 1, 'file file-php', '', 256, 0),
(1412, 'critere', 'php', '', '', 1, 'file file-php', '', 256, 0),
(1413, 'don_adr', 'php', '', '', 1, 'file file-php', '', 256, 0),
(1414, 'lignefacturecogilog', 'php', '', '', 1, 'file file-php', '', 256, 0),
(1415, 'return', 'php', '', '', 1, 'file file-php', '', 256, 0),
(1416, 'demo', 'php', '', '', 1, 'file file-htm', 'null', 256, 0),
(1417, 'dates', 'php', '', '', 1, 'file file-c', 'null', 256, 0),
(1418, 'edQ - php', 'folder', '', '', 1, 'file file-folder-sys', '', 256, 0),
(1420, 'node', 'php', '', '', 1, 'file file-c', '', 256, 0),
(1421, 'arguments', 'php', NULL, NULL, 1, 'file file-php', NULL, 256, 0),
(1422, 'callstack', 'php', '', '', 1, 'file file-php', '', 256, 0),
(1423, 'dataSource', 'dataSource', '', '', 1, 'file file-iso', '', 256, 0),
(1424, 'Courriers', 'folder', NULL, NULL, 1, 'file file-folder', NULL, 256, 0),
(1425, '140910 - Appel a don 2014', 'folder', NULL, NULL, 1, 'file file-folder', NULL, 256, 0),
(1426, 'petits donateurs recents', 'php', NULL, NULL, 1, 'file file-php', NULL, 256, 0),
(1427, 'donateurs web recents', 'php', '', '', 1, 'file file-php', '', 256, 0),
(1428, 'donateurs ne pas relancer', 'php', '', '', 1, 'file file-php', '', 256, 0),
(1429, 'donateurs NEF', 'php', '', '', 1, 'file file-php', '', 256, 0),
(1430, 'Statistiques', 'folder', NULL, NULL, 1, 'file file-folder', NULL, 256, 0),
(1431, 'Dons', 'folder', NULL, NULL, 1, 'file file-folder', NULL, 256, 0),
(1432, 'par type de don et annee', 'php', '', '', 1, 'file file-php', '', 256, 0),
(1433, 'prelevement', 'php', '', '', 1, 'file file-php', '', 256, 0),
(1434, 'prlv histo details', 'php', '', '', 1, 'file file-php', '', 256, 0),
(1435, 'inscr donateurs web', 'php', '', '', 1, 'file file-php', '', 256, 0),
(1436, 'bloc', 'php', '', '', 1, 'file file-htm', 'false', 256, 0),
(1437, 'collapsed', 'html', NULL, NULL, 1, 'file file-html', NULL, 256, 0),
(1438, 'css', 'css', NULL, NULL, 1, 'file file-css', NULL, 256, 0),
(1440, 'html', 'folder', NULL, NULL, 1, 'file file-folder', NULL, 256, 0),
(1441, 'data', 'folder', '', '', 1, 'file file-folder', '', 256, 0),
(1442, 'from html', 'php', '', '', 1, 'file file-php', '', 256, 0),
(1443, 'from rows', 'php', '', '', 1, 'file file-php', '', 256, 0),
(1444, 'rows', 'folder', '', '', 1, 'file file-folder', 'null', 256, 0),
(1445, 'from html', 'php', '', '', 1, 'file file-php', '', 256, 0),
(1446, 'test', 'default', NULL, NULL, 1, 'file file-file', NULL, 256, 0),
(1447, 'to html', 'php', '', '', 1, 'file file-php', '', 256, 0),
(1448, 'demo', 'default', NULL, NULL, 0, 'file file-file', NULL, 256, 0),
(1449, 'dataTable', 'php', '', '', 0, 'file file-php', '', 256, 0),
(1450, 'demo', 'default', NULL, NULL, 0, 'file file-file', NULL, 256, 0),
(1455, 'test', 'default', NULL, NULL, 1, 'file file-file', NULL, 256, 0),
(1456, 'test', 'default', NULL, NULL, 1, 'file file-file', NULL, 256, 0),
(1457, 'download link', 'php', NULL, NULL, 1, 'file file-php', NULL, 256, 0),
(1458, 'test', 'default', NULL, NULL, 1, 'file file-file', NULL, 256, 0),
(1459, 'Contacts', 'folder', NULL, NULL, 1, NULL, NULL, 256, 0),
(1460, 'Groupes', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1461, 'Liste', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1462, 'dataSource', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1463, 'Test', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1464, 'test', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1465, 'Cogilog', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1466, 'Xml', 'folder', NULL, NULL, 1, NULL, NULL, 256, 0),
(1468, 'Filters', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1469, 'Recherche', 'folder', NULL, NULL, 1, NULL, NULL, 256, 0),
(1471, 'pflogsumm', 'folder', NULL, NULL, 1, NULL, NULL, 256, 0),
(1472, 'parser', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1474, 'is_utf8', 'php', NULL, NULL, 1, 'file file-php', NULL, 256, 0),
(1475, 'Prelevements', 'folder', NULL, NULL, 1, 'file file-folder', NULL, 256, 0),
(1476, 'Arret de prlvt', 'php', '', '', 1, 'file file-php', '', 256, 0),
(1478, 'Dons post-prlvt', 'php', '', '', 1, 'file file-php', '', 256, 0),
(1479, 'Dons pd prlvt', 'php', '', '', 1, 'file file-php', '', 256, 0),
(1480, 'test', 'php', '', '', 1, 'file file-php', '', 256, 0),
(1481, 'Dons par annee', 'php', '', '', 1, 'file file-php', '', 256, 0),
(1482, '140916 - Re-adhesion et AG2015', 'folder', NULL, NULL, 1, 'file file-folder', NULL, 256, 0),
(1483, 'Liste groupes', 'php', NULL, NULL, 1, 'file file-php', NULL, 256, 0),
(1486, 'escape', 'html', NULL, NULL, 1, 'file file-html', NULL, 256, 0),
(1487, 'Dons par exercice', 'php', '', '', 1, 'file file-php', '', 256, 0),
(1488, 'Prlvnts par exercice', 'php', '', '', 1, 'file file-php', '', 256, 0),
(1489, 'En prlvnt sans don recent', 'php', '', '', 1, 'file file-php', '', 256, 0),
(1497, 'en cours d''import', 'default', '', '', 1, 'file file-file', '', 256, 0),
(1498, 'donateurs joignables', 'php', NULL, NULL, 1, 'file file-php', NULL, 256, 0),
(1499, 'synthese', 'php', NULL, NULL, 1, 'file file-php', NULL, 256, 0),
(1500, 'TODO', 'default', NULL, NULL, 1, 'file file-file', NULL, 256, 0),
(1501, '140924 - relance vieux abonnes', 'folder', NULL, NULL, 1, 'file file-folder', NULL, 256, 0),
(1503, 'decompte', 'php', NULL, NULL, 1, 'file file-php', NULL, 256, 0),
(1504, 'decompte', 'php', NULL, NULL, 1, 'file file-php', NULL, 256, 0),
(1505, 'Criteres', 'folder', NULL, NULL, 1, 'file file-folder', NULL, 256, 0),
(1506, 'abo_paye', 'php', NULL, NULL, 1, 'file file-php', NULL, 256, 0),
(1507, 'Abonnements', 'folder', NULL, NULL, 1, 'file file-folder', NULL, 256, 0),
(1508, 'dernier abo_paye', 'php', NULL, NULL, 1, 'file file-php', NULL, 256, 0),
(1509, 'abonnes', 'php', NULL, NULL, 1, 'file file-php', NULL, 256, 0),
(1510, 'doublons', 'php', NULL, NULL, 1, 'file file-php', NULL, 256, 0),
(1511, 'Revue', 'folder', NULL, NULL, 1, 'file file-folder', NULL, 256, 0),
(1512, 'durees des abonnements', 'php', NULL, NULL, 1, 'file file-php', NULL, 256, 0),
(1513, 'abonnes par revue', 'php', NULL, NULL, 1, 'file file-php', NULL, 256, 0),
(1514, 'dons des anciens', 'php', NULL, NULL, 1, 'file file-php', NULL, 256, 0),
(1515, 'panel final', 'php', NULL, NULL, 1, 'file file-php', NULL, 256, 0),
(1516, 'vTigerCRM', 'folder', NULL, NULL, 1, NULL, NULL, 256, 0),
(1517, 'Dev', 'folder', NULL, NULL, 1, NULL, NULL, 256, 0),
(1518, 'Creer un module', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1519, 'Entity', 'folder', NULL, NULL, 1, NULL, NULL, 256, 0),
(1520, 'Champ Titre', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1521, 'Intro', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1522, 'Label par defaut', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1523, 'fields', 'folder', NULL, NULL, 1, NULL, NULL, 256, 0),
(1524, 'field contenant l''enregistrement d''un autre module', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1525, 'Intro', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1526, 'liste des types', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1527, 'Modifier les champs Activity', 'folder', NULL, NULL, 1, NULL, NULL, 256, 0),
(1528, 'Taches', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1529, 'picklist libre', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1530, 'Modifs', 'folder', NULL, NULL, 1, NULL, NULL, 256, 0),
(1531, 'Afficher davantage dans Calendar', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1532, 'cache in session', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1533, 'field currency', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1534, 'getDisplayValue', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1535, 'Modifs initiales', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1536, 'RelationListView', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1537, 'Notes', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1538, 'Outils', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1539, 'Sites web', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1540, 'Todo', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1541, 'Translations', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1542, 'UI', 'folder', NULL, NULL, 1, NULL, NULL, 256, 0),
(1543, 'masquer une colonne', 'php', NULL, NULL, 1, NULL, NULL, 256, 0),
(1544, 'reset tabs', 'js', NULL, NULL, 1, 'file file-js', NULL, 256, 0),
(1545, 'user rights', 'html', '', '', 1, 'file file-c', 'false', 256, 0),
(1546, 'user preferences', 'html', '', '', 1, 'file file-c', 'false', 256, 0),
(1547, 'v20141006.2158', 'php', '', '', 1, 'file file-php', '', 256, 0);

-- --------------------------------------------------------

--
-- Structure de la table `tree_struct`
--

DROP TABLE IF EXISTS `tree_struct`;
CREATE TABLE IF NOT EXISTS `tree_struct` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lft` int(10) unsigned NOT NULL,
  `rgt` int(10) unsigned NOT NULL,
  `lvl` int(10) unsigned NOT NULL,
  `pid` int(10) unsigned NOT NULL,
  `pos` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1550 ;

--
-- Contenu de la table `tree_struct`
--

INSERT INTO `tree_struct` (`id`, `lft`, `rgt`, `lvl`, `pid`, `pos`) VALUES
(1, 1, 544, 0, 0, 0),
(1065, 204, 205, 3, 1095, 2),
(1069, 2, 21, 1, 1, 0),
(1070, 19, 20, 2, 1069, 5),
(1074, 190, 215, 1, 1, 3),
(1078, 195, 196, 2, 1074, 2),
(1094, 206, 207, 3, 1095, 3),
(1095, 199, 208, 2, 1074, 4),
(1097, 202, 203, 3, 1095, 1),
(1098, 200, 201, 3, 1095, 0),
(1100, 11, 18, 2, 1069, 4),
(1101, 16, 17, 3, 1100, 2),
(1102, 14, 15, 3, 1100, 1),
(1103, 209, 210, 2, 1074, 5),
(1104, 193, 194, 2, 1074, 1),
(1105, 9, 10, 2, 1069, 3),
(1106, 7, 8, 2, 1069, 2),
(1107, 191, 192, 2, 1074, 0),
(1111, 5, 6, 2, 1069, 1),
(1121, 60, 65, 3, 1321, 0),
(1123, 12, 13, 3, 1100, 0),
(1127, 62, 61, 3, 1121, 1),
(1133, 22, 173, 1, 1, 1),
(1134, 197, 198, 2, 1074, 3),
(1157, 3, 4, 2, 1069, 0),
(1158, 216, 293, 1, 1, 4),
(1159, 268, 275, 3, 1216, 0),
(1160, 271, 272, 4, 1159, 1),
(1161, 273, 274, 4, 1159, 2),
(1162, 269, 270, 4, 1159, 0),
(1166, 217, 218, 2, 1158, 0),
(1167, 454, 543, 1, 1, 8),
(1168, 460, 503, 3, 1187, 0),
(1169, 483, 496, 4, 1168, 2),
(1170, 484, 487, 5, 1169, 0),
(1171, 485, 486, 6, 1170, 0),
(1172, 463, 482, 4, 1168, 1),
(1173, 476, 481, 5, 1172, 2),
(1174, 477, 478, 6, 1173, 0),
(1175, 479, 480, 6, 1173, 1),
(1176, 470, 475, 5, 1172, 1),
(1177, 471, 472, 6, 1176, 0),
(1178, 473, 474, 6, 1176, 1),
(1179, 464, 469, 5, 1172, 0),
(1180, 465, 466, 6, 1179, 0),
(1181, 467, 468, 6, 1179, 1),
(1182, 488, 495, 5, 1169, 1),
(1183, 489, 490, 6, 1182, 0),
(1184, 491, 492, 6, 1182, 1),
(1185, 493, 494, 6, 1182, 2),
(1186, 497, 498, 4, 1168, 3),
(1187, 459, 522, 2, 1167, 1),
(1188, 504, 521, 3, 1187, 1),
(1189, 513, 520, 4, 1188, 1),
(1190, 514, 515, 5, 1189, 0),
(1191, 516, 517, 5, 1189, 1),
(1192, 518, 519, 5, 1189, 2),
(1195, 359, 360, 4, 1370, 2),
(1196, 384, 385, 3, 1387, 2),
(1198, 357, 358, 4, 1370, 1),
(1199, 523, 526, 2, 1167, 2),
(1200, 524, 525, 3, 1199, 0),
(1202, 361, 364, 4, 1370, 3),
(1203, 362, 363, 5, 1202, 0),
(1204, 211, 214, 2, 1074, 6),
(1205, 212, 213, 3, 1204, 0),
(1208, 505, 512, 4, 1188, 0),
(1209, 506, 507, 5, 1208, 0),
(1210, 508, 509, 5, 1208, 1),
(1211, 510, 511, 5, 1208, 2),
(1215, 280, 281, 3, 1216, 3),
(1216, 267, 282, 2, 1158, 7),
(1218, 278, 279, 3, 1216, 2),
(1220, 527, 530, 2, 1167, 3),
(1221, 528, 529, 3, 1220, 0),
(1222, 455, 458, 2, 1167, 0),
(1229, 219, 226, 2, 1158, 1),
(1230, 220, 221, 3, 1229, 0),
(1231, 222, 225, 3, 1229, 1),
(1232, 390, 419, 1, 1, 6),
(1233, 538, 539, 3, 1441, 0),
(1234, 405, 418, 2, 1232, 1),
(1235, 456, 457, 3, 1222, 0),
(1236, 540, 541, 3, 1441, 1),
(1239, 35, 58, 2, 1133, 2),
(1240, 36, 57, 3, 1239, 0),
(1241, 45, 48, 4, 1240, 3),
(1247, 42, 43, 5, 1248, 0),
(1248, 41, 44, 4, 1240, 2),
(1249, 39, 40, 4, 1240, 1),
(1250, 231, 232, 2, 1158, 3),
(1251, 355, 356, 4, 1370, 0),
(1319, 227, 230, 2, 1158, 2),
(1320, 228, 229, 3, 1319, 0),
(1321, 59, 66, 2, 1133, 3),
(1322, 233, 248, 2, 1158, 4),
(1323, 241, 242, 4, 1324, 0),
(1324, 240, 243, 3, 1322, 2),
(1325, 253, 254, 4, 1327, 1),
(1326, 249, 258, 2, 1158, 5),
(1327, 250, 257, 3, 1326, 0),
(1328, 236, 239, 3, 1322, 1),
(1329, 237, 238, 4, 1328, 0),
(1331, 251, 252, 4, 1327, 0),
(1341, 63, 64, 4, 1121, 0),
(1342, 259, 266, 2, 1158, 6),
(1344, 260, 261, 3, 1342, 0),
(1345, 420, 453, 1, 1, 7),
(1346, 421, 424, 2, 1345, 0),
(1347, 422, 423, 3, 1346, 0),
(1348, 425, 436, 2, 1345, 1),
(1349, 434, 435, 3, 1348, 1),
(1350, 426, 433, 3, 1348, 0),
(1351, 431, 432, 4, 1350, 1),
(1354, 49, 56, 4, 1240, 4),
(1355, 54, 55, 5, 1354, 2),
(1356, 276, 277, 3, 1216, 1),
(1357, 234, 235, 3, 1322, 0),
(1360, 437, 438, 2, 1345, 2),
(1361, 427, 430, 4, 1350, 0),
(1362, 428, 429, 5, 1361, 0),
(1363, 174, 189, 1, 1, 2),
(1364, 46, 47, 5, 1241, 0),
(1365, 175, 188, 2, 1363, 0),
(1366, 186, 187, 3, 1365, 2),
(1367, 178, 185, 3, 1365, 1),
(1368, 183, 184, 4, 1367, 2),
(1369, 181, 182, 4, 1367, 1),
(1370, 354, 369, 3, 1418, 1),
(1371, 439, 444, 2, 1345, 3),
(1372, 440, 441, 3, 1371, 0),
(1373, 442, 443, 3, 1371, 1),
(1374, 372, 373, 3, 1418, 3),
(1377, 283, 286, 2, 1158, 8),
(1378, 284, 285, 3, 1377, 0),
(1383, 262, 263, 3, 1342, 1),
(1384, 255, 256, 4, 1327, 2),
(1385, 370, 371, 3, 1418, 2),
(1386, 294, 389, 1, 1, 5),
(1387, 379, 388, 2, 1386, 2),
(1388, 287, 292, 2, 1158, 9),
(1390, 500, 501, 5, 1391, 0),
(1391, 499, 502, 4, 1168, 4),
(1392, 223, 224, 4, 1231, 0),
(1393, 382, 383, 3, 1387, 1),
(1398, 532, 533, 3, 1399, 0),
(1399, 531, 534, 2, 1167, 4),
(1404, 67, 172, 2, 1133, 4),
(1405, 70, 99, 3, 1404, 1),
(1406, 73, 98, 4, 1405, 1),
(1407, 76, 77, 5, 1406, 1),
(1408, 86, 87, 5, 1406, 6),
(1409, 74, 75, 5, 1406, 0),
(1410, 68, 69, 3, 1404, 0),
(1411, 78, 79, 5, 1406, 2),
(1412, 84, 85, 5, 1406, 5),
(1413, 80, 81, 5, 1406, 3),
(1414, 82, 83, 5, 1406, 4),
(1415, 365, 368, 4, 1370, 4),
(1416, 366, 367, 5, 1415, 0),
(1417, 380, 381, 3, 1387, 0),
(1418, 351, 378, 2, 1386, 1),
(1420, 352, 353, 3, 1418, 0),
(1421, 244, 245, 3, 1322, 3),
(1422, 246, 247, 3, 1322, 4),
(1423, 71, 72, 4, 1405, 0),
(1424, 100, 129, 3, 1404, 2),
(1425, 101, 116, 4, 1424, 0),
(1426, 104, 105, 5, 1425, 1),
(1427, 106, 107, 5, 1425, 2),
(1428, 108, 109, 5, 1425, 3),
(1429, 112, 113, 5, 1425, 5),
(1430, 130, 171, 3, 1404, 3),
(1431, 143, 150, 4, 1430, 1),
(1432, 148, 149, 5, 1431, 2),
(1433, 88, 89, 5, 1406, 7),
(1434, 90, 91, 5, 1406, 8),
(1435, 92, 93, 5, 1406, 9),
(1436, 445, 450, 2, 1345, 4),
(1437, 446, 447, 3, 1436, 0),
(1438, 448, 449, 3, 1436, 1),
(1440, 535, 536, 2, 1167, 5),
(1441, 537, 542, 2, 1167, 6),
(1442, 410, 413, 3, 1234, 1),
(1443, 406, 409, 3, 1234, 0),
(1444, 391, 404, 2, 1232, 0),
(1445, 400, 403, 3, 1444, 1),
(1446, 401, 402, 4, 1445, 0),
(1447, 392, 399, 3, 1444, 0),
(1448, 397, 398, 4, 1447, 1),
(1449, 393, 396, 4, 1447, 0),
(1450, 394, 395, 5, 1449, 0),
(1455, 411, 412, 4, 1442, 0),
(1456, 407, 408, 4, 1443, 0),
(1457, 414, 417, 3, 1234, 2),
(1458, 415, 416, 4, 1457, 0),
(1459, 27, 34, 2, 1133, 1),
(1460, 28, 33, 3, 1459, 0),
(1461, 31, 32, 4, 1460, 1),
(1462, 29, 30, 4, 1460, 0),
(1463, 37, 38, 4, 1240, 0),
(1464, 52, 53, 5, 1354, 1),
(1465, 50, 51, 5, 1354, 0),
(1466, 23, 26, 2, 1133, 0),
(1468, 24, 25, 3, 1466, 0),
(1469, 461, 462, 4, 1168, 0),
(1471, 176, 177, 3, 1365, 0),
(1472, 179, 180, 4, 1367, 0),
(1474, 386, 387, 3, 1387, 3),
(1475, 131, 142, 4, 1430, 0),
(1476, 134, 135, 5, 1475, 1),
(1478, 136, 137, 5, 1475, 2),
(1479, 138, 139, 5, 1475, 3),
(1480, 140, 141, 5, 1475, 4),
(1481, 144, 145, 5, 1431, 0),
(1482, 117, 120, 4, 1424, 1),
(1483, 118, 119, 5, 1482, 0),
(1486, 451, 452, 2, 1345, 5),
(1487, 146, 147, 5, 1431, 1),
(1488, 132, 133, 5, 1475, 0),
(1489, 110, 111, 5, 1425, 4),
(1497, 94, 95, 5, 1406, 10),
(1498, 102, 103, 5, 1425, 0),
(1499, 114, 115, 5, 1425, 6),
(1500, 96, 97, 5, 1406, 11),
(1501, 121, 128, 4, 1424, 2),
(1503, 124, 125, 5, 1501, 1),
(1504, 152, 153, 5, 1505, 0),
(1505, 151, 154, 4, 1430, 2),
(1506, 158, 159, 5, 1507, 1),
(1507, 155, 164, 4, 1430, 3),
(1508, 162, 163, 5, 1507, 3),
(1509, 160, 161, 5, 1507, 2),
(1510, 156, 157, 5, 1507, 0),
(1511, 165, 170, 4, 1430, 4),
(1512, 168, 169, 5, 1511, 1),
(1513, 166, 167, 5, 1511, 0),
(1514, 126, 127, 5, 1501, 2),
(1515, 122, 123, 5, 1501, 0),
(1516, 295, 350, 2, 1386, 0),
(1517, 296, 349, 3, 1516, 0),
(1518, 347, 348, 4, 1517, 9),
(1519, 339, 346, 4, 1517, 8),
(1520, 344, 345, 5, 1519, 2),
(1521, 342, 343, 5, 1519, 1),
(1522, 340, 341, 5, 1519, 0),
(1523, 325, 338, 4, 1517, 7),
(1524, 336, 337, 5, 1523, 4),
(1525, 334, 335, 5, 1523, 3),
(1526, 332, 333, 5, 1523, 2),
(1527, 328, 331, 5, 1523, 1),
(1528, 329, 330, 6, 1527, 0),
(1529, 326, 327, 5, 1523, 0),
(1530, 311, 324, 4, 1517, 6),
(1531, 322, 323, 5, 1530, 5),
(1532, 320, 321, 5, 1530, 4),
(1533, 318, 319, 5, 1530, 3),
(1534, 316, 317, 5, 1530, 2),
(1535, 314, 315, 5, 1530, 1),
(1536, 312, 313, 5, 1530, 0),
(1537, 309, 310, 4, 1517, 5),
(1538, 307, 308, 4, 1517, 4),
(1539, 305, 306, 4, 1517, 3),
(1540, 303, 304, 4, 1517, 2),
(1541, 301, 302, 4, 1517, 1),
(1542, 297, 300, 4, 1517, 0),
(1543, 298, 299, 5, 1542, 0),
(1544, 264, 265, 3, 1342, 2),
(1545, 374, 375, 3, 1418, 4),
(1546, 376, 377, 3, 1418, 5),
(1547, 288, 289, 3, 1388, 0),
(1548, 290, 291, 3, 1388, 1);

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `IdUser` int(11) NOT NULL COMMENT '= IdContact',
  `Enabled` tinyint(1) NOT NULL DEFAULT '1',
  `Password` varchar(64) CHARACTER SET utf8 NOT NULL,
  `UserType` smallint(4) NOT NULL,
  PRIMARY KEY (`IdUser`),
  KEY `Enabled` (`Enabled`),
  KEY `UserType` (`UserType`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `user`
--

INSERT INTO `user` (`IdUser`, `Enabled`, `Password`, `UserType`) VALUES
(1, 1, '*BE353D0D7826681F8B7C136ED9824915F5B99E7D', 1),
(715, 1, '*BE353D0D7826681F8B7C136ED9824915F5B99E7D', 64),
(720, 1, '*BE353D0D7826681F8B7C136ED9824915F5B99E7D', 4),
(722, 1, '*95DAD11F6C3D83D9E281195E792433EB05C15614', 4),
(742, 1, '*8C90040B372F63A4BB3B764BE90FD3EC38D2E227', 4),
(762, 1, '*CF5FEEE70223AC0CB8D559661D4145EA12DD033D', 4),
(763, 1, '*B1F9ACC9F58F4DA857A97AC2BA02FE1A51A82F32', 64),
(764, 1, '*6A00C25B7CD0860BF1F49C2FA85AFBDCC1B92865', 64),
(765, 1, '*75562E0C956E92996DA66DC7803FF4888035599A', 64);

-- --------------------------------------------------------

--
-- Structure de la table `user_param`
--

DROP TABLE IF EXISTS `user_param`;
CREATE TABLE IF NOT EXISTS `user_param` (
  `id` int(10) unsigned NOT NULL,
  `param` varchar(32) NOT NULL,
  `domain` varchar(32) NOT NULL,
  `value` text,
  `sortIndex` int(11) NOT NULL DEFAULT '999',
  PRIMARY KEY (`id`,`param`,`domain`),
  KEY `sortIndex` (`sortIndex`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `user_param`
--

INSERT INTO `user_param` (`id`, `param`, `domain`, `value`, `sortIndex`) VALUES
(1, 'DIV#favpanel', 'jstree-favpanel-nodes', '{"1319":{"h":24,"w":82,"x":264,"y":16,"text":"Sauvegarde","icon":"file file-folder"},"1378":{"h":24,"w":73,"x":160,"y":16,"text":"Recherche","icon":"file file-iso"},"1356":{"h":24,"w":73,"x":64,"y":16,"text":"Recherche","icon":"file file-iso"}}', 0),
(1, 'form', '_Pages/Recherche', '{"root":"\\/edQ\\/","content":"HTTP_REFER"}', 0),
(1, 'form', '_Sources/Recherche', '{"root":"\\/","root_from_pages":true,"content":"get_callstack()","extensions":"php|js|css|html?","exclude_paths":"pages|logs|cache|tmp|sessions"}', 0);

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `node_comment`
--
ALTER TABLE `node_comment`
  ADD CONSTRAINT `node_comment_ibfk_1` FOREIGN KEY (`id`) REFERENCES `tree_data` (`id`);

--
-- Contraintes pour la table `node_param`
--
ALTER TABLE `node_param`
  ADD CONSTRAINT `node_param_ibfk_1` FOREIGN KEY (`id`) REFERENCES `tree_data` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
